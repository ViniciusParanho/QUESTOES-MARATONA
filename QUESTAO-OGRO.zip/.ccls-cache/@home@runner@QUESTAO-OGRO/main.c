#include <stdio.h>

int main() {
    int N;
    printf("\n DIGITE O NUMERO PARA MOSTRAR PLEO DEDO : ");
    scanf("%d", &N);

    if (N < 0 || N > 10) {
        printf("O número deve estar entre 0 e 10.\n");
        return 1;
    }

    if (N <= 5) {
        // Mão esquerda mostra N dedos
        for (int i = 0; i < N; i++) {
            printf("I");
        }
        printf("\n");

        // Mão direita é fechada
        printf("*\n");
    } else {
        // Mão esquerda mostra todos os 5 dedos
        for (int i = 0; i < 5; i++) {
            printf("I");
        }
        printf("\n");

        // Mão direita mostra N - 5 dedos
        for (int i = 0; i < N - 5; i++) {
            printf("I");
        }
        printf("\n");
    }

    return 0;
}
