#include <stdio.h>

int main() {
    int L, C;
    int A, B;
    int i, j;

    // Lê as dimensões do salão
    scanf("%d %d", &L, &C);

    // Lê a posição inicial do robô
    scanf("%d %d", &A, &B);

    // Ajusta a posição inicial para índices baseados em zero
    A--;
    B--;

    // Lê o mapa do salão
    int mapa[L][C];
    for (i = 0; i < L; i++) {
        for (j = 0; j < C; j++) {
            scanf("%d", &mapa[i][j]);
        }
    }

    // Define os movimentos possíveis: Norte, Sul, Leste, Oeste
    int dx[] = {-1, 1, 0, 0};
    int dy[] = {0, 0, 1, -1};

    // Inicializa a posição e a direção do robô
    int x = A, y = B;
    int direcao = -1;

    // Determina a direção inicial
    for (i = 0; i < 4; i++) {
        int nx = x + dx[i];
        int ny = y + dy[i];
        if (nx >= 0 && nx < L && ny >= 0 && ny < C && mapa[nx][ny] == 1) {
            direcao = i;
            break;
        }
    }

    // Move o robô na direção determinada até não poder mais se mover
    while (1) {
        int nx = x + dx[direcao];
        int ny = y + dy[direcao];
        if (nx >= 0 && nx < L && ny >= 0 && ny < C && mapa[nx][ny] == 1) {
            x = nx;
            y = ny;
        } else {
            break;
        }
    }

    // Imprime a posição final do robô ajustada para índices baseados em 1
    printf("%d %d\n", x + 1, y + 1);

    return 0;
}
