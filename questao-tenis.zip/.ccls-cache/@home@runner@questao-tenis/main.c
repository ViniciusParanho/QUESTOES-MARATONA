#include <stdio.h>

int main() {
    char resultado;
    int vitorias = 0;

    // FAZER LEITURA DOS 6 JOGOS
    for (int i = 0; i < 6; i++) {
        printf ("\n DIGITE V OU P : ");
        scanf(" %c", &resultado);
        if (resultado == 'V') {
            vitorias += 1;
        }
    }

    // MOSTRAR QUAL GRUPO E DPS DA LEITURA
    if (vitorias == 5 || vitorias == 6) {
        printf("  1 \n");
    } else if (vitorias == 3 || vitorias == 4) {
        printf("  2 \n");
    } else if (vitorias == 1 || vitorias == 2) {
        printf("  3 \n");
    } else {
        printf(" -1 \n");
    }

    return 0;
}